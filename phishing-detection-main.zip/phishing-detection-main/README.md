# phishing-detection
A chrome extension that detects phishing URLs in an efficient way based on URL features by alerting and warning users if they open up or browses some malicious url using phishing URLs SVM classifier.
